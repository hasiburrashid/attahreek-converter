package com.attahreek.converter;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewFeature;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final int REQ_FILE = 11;
    private static final int REQ_PERM = 12;

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;

    private final Map<String, Pending> saves = new HashMap<String, Pending>();
    private int saveSeq = 0;

    private static final class Pending {
        String name, mime;
        OutputStream out;
        Uri uri;      // MediaStore (API 29+)
        File file;    // legacy
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(true);

        // ফোনের সিস্টেম ডার্ক-মোড যেন অ্যাপের রং উল্টে না দেয় — ডিফল্ট সবসময় লাইট
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, false);
            }
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                WebSettingsCompat.setForceDark(s, WebSettingsCompat.FORCE_DARK_OFF);
            }
        } catch (Throwable ignored) { }
        applyBars(false);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "লিংক খোলা যায়নি", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        "application/msword", "application/octet-stream"});
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(Intent.createChooser(i, "ফাইল নির্বাচন করুন"), REQ_FILE);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.loadUrl("https://" + HOST + "/assets/www/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && filePathCallback != null) {
            Uri[] out = null;
            if (res == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    ClipData c = data.getClipData();
                    out = new Uri[c.getItemCount()];
                    for (int i = 0; i < out.length; i++) out[i] = c.getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    out = new Uri[] {data.getData()};
                }
            }
            filePathCallback.onReceiveValue(out);
            filePathCallback = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }

    /** স্ট্যাটাস বার ও নেভিগেশন বারের রং (লাইট = সবুজ, নাইট = গাঢ় সবুজ)। */
    private void applyBars(boolean night) {
        try {
            getWindow().setStatusBarColor(night ? 0xFF0B3D0B : 0xFF007A00);
            getWindow().setNavigationBarColor(night ? 0xFF121212 : 0xFFFFFFFF);
            if (Build.VERSION.SDK_INT >= 26) {
                int f = getWindow().getDecorView().getSystemUiVisibility();
                if (night) f &= ~android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                else f |= android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                getWindow().getDecorView().setSystemUiVisibility(f);
            }
        } catch (Throwable ignored) { }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent e) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            // ড্রয়ার খোলা থাকলে আগে সেটা বন্ধ হবে
            web.evaluateJavascript("(window.__backHandled&&window.__backHandled())?'1':'0'", new ValueCallback<String>() {
                @Override public void onReceiveValue(String v) {
                    if (v != null && v.contains("1")) return;
                    if (web.canGoBack()) web.goBack(); else finish();
                }
            });
            return true;
        }
        return super.onKeyDown(keyCode, e);
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private void toast(final String m) {
        runOnUiThread(new Runnable() {
            @Override public void run() { Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show(); }
        });
    }

    private static String safeName(String n) {
        if (n == null || n.trim().length() == 0) return "file";
        return n.replaceAll("[\\\\/:*?\"<>|\\u0000-\\u001F]", "_");
    }

    /** JavaScript bridge used by js/android-shim.js. */
    private final class Bridge {

        @JavascriptInterface
        public void toast(String m) { MainActivity.this.toast(m); }

        @JavascriptInterface
        public void setNight(final boolean night) {
            runOnUiThread(new Runnable() {
                @Override public void run() { applyBars(night); }
            });
        }

        @JavascriptInterface
        public void copyText(final String t) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("text", t));
                }
            });
        }

        @JavascriptInterface
        public String pasteText() {
            final String[] r = {""};
            final Object lock = new Object();
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
                            CharSequence c = cm.getPrimaryClip().getItemAt(0).coerceToText(MainActivity.this);
                            if (c != null) r[0] = c.toString();
                        }
                    } catch (Exception e) {
                        r[0] = "";
                    }
                    synchronized (lock) { lock.notifyAll(); }
                }
            });
            synchronized (lock) {
                try { lock.wait(1500); } catch (InterruptedException e) { }
            }
            return r[0];
        }

        @JavascriptInterface
        public synchronized String beginSave(String name, String mime) {
            try {
                Pending p = new Pending();
                p.name = safeName(name);
                p.mime = (mime == null || mime.length() == 0) ? "application/octet-stream" : mime;
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, p.name);
                    cv.put(MediaStore.Downloads.MIME_TYPE, p.mime);
                    cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    p.uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (p.uri == null) return "";
                    p.out = getContentResolver().openOutputStream(p.uri);
                } else {
                    if (Build.VERSION.SDK_INT >= 23
                            && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                requestPermissions(new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_PERM);
                            }
                        });
                        MainActivity.this.toast("অনুমতি দিয়ে আবার ডাউনলোড চাপুন");
                        return "";
                    }
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    dir.mkdirs();
                    File f = new File(dir, p.name);
                    int n = 2;
                    String base = p.name, ext = "";
                    int dot = base.lastIndexOf('.');
                    if (dot > 0) { ext = base.substring(dot); base = base.substring(0, dot); }
                    while (f.exists()) f = new File(dir, base + " (" + (n++) + ")" + ext);
                    p.file = f;
                    p.out = new FileOutputStream(f);
                }
                String id = "s" + (++saveSeq);
                saves.put(id, p);
                return id;
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public synchronized boolean appendSave(String id, String b64) {
            Pending p = saves.get(id);
            if (p == null) return false;
            try {
                p.out.write(Base64.decode(b64, Base64.DEFAULT));
                return true;
            } catch (Exception e) {
                abort(id);
                return false;
            }
        }

        @JavascriptInterface
        public synchronized String finishSave(String id) {
            Pending p = saves.remove(id);
            if (p == null) return "";
            try {
                p.out.flush();
                p.out.close();
                if (p.file != null) {
                    android.media.MediaScannerConnection.scanFile(MainActivity.this,
                            new String[] {p.file.getAbsolutePath()}, null, null);
                }
                return p.name;
            } catch (Exception e) {
                return "";
            }
        }

        private void abort(String id) {
            Pending p = saves.remove(id);
            if (p == null) return;
            try { p.out.close(); } catch (Exception e) { }
            if (p.uri != null) getContentResolver().delete(p.uri, null, null);
            if (p.file != null) p.file.delete();
        }
    }
}
