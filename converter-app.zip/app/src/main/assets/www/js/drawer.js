/* বাম পাশের ড্রয়ার (মেনু) */
(function(){
  var body, drawer, scrim;
  function open(){ body.classList.add('drawer-open'); drawer.setAttribute('aria-hidden','false'); }
  function close(){ body.classList.remove('drawer-open'); drawer.setAttribute('aria-hidden','true'); }
  function isOpen(){ return !!body && body.classList.contains('drawer-open'); }
  window.__backHandled=function(){ if(isOpen()){ close(); return true; } return false; };
  document.addEventListener('DOMContentLoaded',function(){
    body=document.body;
    drawer=document.getElementById('drawer'); scrim=document.getElementById('drawerScrim');
    document.getElementById('menuBtn').addEventListener('click',function(){ isOpen()?close():open(); });
    scrim.addEventListener('click',close);
    Array.prototype.forEach.call(drawer.querySelectorAll('[data-goto]'),function(a){
      a.addEventListener('click',function(){
        var t=document.querySelector('#tabbar [data-tab="'+a.getAttribute('data-goto')+'"]');
        if(t) t.click(); close();
      });
    });
    Array.prototype.forEach.call(drawer.querySelectorAll('a[href]'),function(a){ a.addEventListener('click',function(){ setTimeout(close,50); }); });
    document.getElementById('drawerNight').addEventListener('click',function(){ window.__setNight(!window.__isNight()); });
    // swipe: বাঁ কিনারা থেকে টেনে খোলা, বামে টেনে বন্ধ
    var sx=null, sy=0, fromEdge=false;
    document.addEventListener('touchstart',function(e){ var t=e.touches[0]; sx=t.clientX; sy=t.clientY; fromEdge=sx<18; },{passive:true});
    document.addEventListener('touchend',function(e){
      if(sx===null) return; var t=e.changedTouches[0], dx=t.clientX-sx, dy=Math.abs(t.clientY-sy);
      if(dy<60){ if(!isOpen() && fromEdge && dx>70) open(); else if(isOpen() && dx<-70) close(); }
      sx=null;
    },{passive:true});
  });
})();
