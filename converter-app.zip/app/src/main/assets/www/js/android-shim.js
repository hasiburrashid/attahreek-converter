// WebView-এর ঘাটতি পূরণ: ক্লিপবোর্ড ও ফাইল সেভ নেটিভ ব্রিজ দিয়ে।
(function () {
  var B = window.AndroidBridge;
  if (!B) return;
  // ---- ক্লিপবোর্ড ----
  var cb = {
    writeText: function (t) { try { B.copyText(String(t)); return Promise.resolve(); } catch (e) { return Promise.reject(e); } },
    readText: function () { try { return Promise.resolve(B.pasteText() || ''); } catch (e) { return Promise.reject(e); } }
  };
  try { Object.defineProperty(navigator, 'clipboard', { value: cb, configurable: true }); } catch (e) { try { navigator.clipboard = cb; } catch (e2) {} }

  // ---- blob ডাউনলোড => ফোনের Downloads ফোল্ডারে ----
  var queue = Promise.resolve();
  function toast(msg) { try { B.toast(msg); } catch (e) {} }
  function blobToChunks(blob, name, mime) {
    return new Promise(function (resolve, reject) {
      var CH = 384 * 1024, off = 0;
      var id = B.beginSave(name, mime || 'application/octet-stream');
      if (!id) { reject(new Error('save-begin-failed')); return; }
      function next() {
        if (off >= blob.size) { var ok = B.finishSave(id); ok ? resolve(ok) : reject(new Error('save-finish-failed')); return; }
        var fr = new FileReader();
        fr.onload = function () {
          var s = fr.result; var i = s.indexOf(',');
          if (!B.appendSave(id, s.substring(i + 1))) { reject(new Error('save-write-failed')); return; }
          off += CH; next();
        };
        fr.onerror = function () { reject(fr.error); };
        fr.readAsDataURL(blob.slice(off, off + CH));
      }
      next();
    });
  }
  function fetchBlob(url) { return fetch(url).then(function (r) { return r.blob(); }); }
  function save(a) {
    var name = a.getAttribute('download') || 'file';
    var href = a.href;
    queue = queue.then(function () {
      return fetchBlob(href).then(function (blob) { return blobToChunks(blob, name, blob.type); })
        .then(function (where) { toast('সেভ হয়েছে: Downloads/' + name); })
        .catch(function (e) { toast('সেভ করা যায়নি: ' + (e && e.message || e)); });
    });
  }
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
    if (a && /^blob:/.test(a.href)) { e.preventDefault(); e.stopPropagation(); save(a); }
  }, true);
})();
