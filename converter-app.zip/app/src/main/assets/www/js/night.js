/* নাইট মোড — ডিফল্ট সবসময় লাইট; ব্যবহারকারী চাইলে চালু করবে */
(function(){
  var KEY='atnight2', root=document.documentElement;
  function get(){ try{return localStorage.getItem(KEY)==='1';}catch(e){return false;} }
  function apply(on){
    if(on) root.setAttribute('data-night','1'); else root.removeAttribute('data-night');
    var m=document.querySelector('meta[name=theme-color]'); if(m) m.setAttribute('content', on?'#0b3d0b':'#009900');
    var c=document.querySelector('meta[name=color-scheme]'); if(c) c.setAttribute('content', on?'dark':'only light');
    var s=document.getElementById('drawerNight'); if(s) s.setAttribute('aria-checked', on?'true':'false');
    try{ if(window.AndroidBridge && AndroidBridge.setNight) AndroidBridge.setNight(!!on); }catch(e){}
  }
  window.__setNight=function(on){ apply(on); try{localStorage.setItem(KEY,on?'1':'0');}catch(e){} };
  window.__isNight=function(){ return root.hasAttribute('data-night'); };
  apply(get());
  document.addEventListener('DOMContentLoaded',function(){
    apply(get());
    var b=document.getElementById('nightBtn');
    if(b) b.addEventListener('click',function(){ window.__setNight(!window.__isNight()); });
  });
})();
