(function(){
  var KEY='atnight', root=document.documentElement;
  function get(){ try{return localStorage.getItem(KEY)==='1';}catch(e){return false;} }
  function apply(on){
    if(on) root.setAttribute('data-night','1'); else root.removeAttribute('data-night');
    var m=document.querySelector('meta[name=theme-color]'); if(m) m.setAttribute('content', on?'#0b3d0b':'#009900');
  }
  apply(get());
  document.addEventListener('DOMContentLoaded',function(){
    var b=document.getElementById('nightBtn'); if(!b) return;
    b.addEventListener('click',function(){
      var on=!root.hasAttribute('data-night'); apply(on);
      try{localStorage.setItem(KEY,on?'1':'0');}catch(e){}
    });
  });
})();
