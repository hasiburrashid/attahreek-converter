// js/loader.js
//
// এই ফাইলটাই একমাত্র "নতুন" লজিক — মডিউলগুলোর নিজস্ব js (common.js,
// converter.js ইত্যাদি) একদম অপরিবর্তিত/আসল রূপেই থাকে, কোনো ES module,
// import/export কিছুই লাগে না। কৌশলটা সহজ:
//
//   ১) একবারে DOM-এ শুধু একটা মডিউলের HTML-ই থাকে (আগেরটা সম্পূর্ণ মুছে ফেলা হয়)।
//      তাই দুই মডিউলে id একই থাকলেও (uniText, ansiText ইত্যাদি) কোনো সংঘর্ষ হয় না।
//   ২) স্ক্রিপ্টগুলো <script> ট্যাগ হিসেবে ঠিক আগের মতোই লোড হয় (classic script,
//      obfuscated/domain-locked কোড হলেও কাজ করবে) — শুধু নিয়ন্ত্রণ করা হয় *কখন*
//      লোড হবে (HTML বসানোর পরে) আর ট্যাব পাল্টালে *পুরনোগুলো* সরিয়ে ফেলা হয়।

const TABS = [
  "unicode-bijoy2003",
  "unicode-bijoyclassic",
  "bijoy2003-bijoyclassic",
  "word-convert",
];

const stage = document.getElementById("stage");
const tabButtons = document.querySelectorAll("#tabbar [data-tab]");

let currentTab = null;
let injectedScriptEls = []; // বর্তমান মডিউলের <script> ট্যাগগুলোর রেফারেন্স
const valueCache = {}; // { tabKey: { elementId: value, ... } } — ট্যাব বদলালেও লেখা মনে রাখার জন্য

function loadScriptSequential(src) {
  return new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = src;
    s.onload = () => resolve(s);
    s.onerror = () => reject(new Error("লোড ব্যর্থ: " + src));
    document.body.appendChild(s);
  });
}

async function activateTab(tabKey) {
  if (tabKey === currentTab) return;

  const oldIndex = TABS.indexOf(currentTab);
  const newIndex = TABS.indexOf(tabKey);
  const movingRight = newIndex > oldIndex; // ডান থেকে বামে যাচ্ছে কিনা বোঝার জন্য

  // ধাপ ১: পুরনো কন্টেন্ট স্লাইড-আউট
  if (currentTab !== null) {
    stage.classList.remove("settled");
    stage.classList.add(movingRight ? "exit-left" : "exit-right");
    await new Promise(r => setTimeout(r, 220));
  }

  // ধাপ ২: বর্তমান প্যানেলের সব textarea-র মান সংরক্ষণ, মুছে ফেলার আগে
  if (currentTab) {
    valueCache[currentTab] = {};
    stage.querySelectorAll("textarea[id]").forEach(el => {
      valueCache[currentTab][el.id] = el.value;
    });
  }

  // ধাপ ৩: পুরনো মডিউলের সব <script> DOM থেকে সরিয়ে ফেলা (গ্লোবাল ফাংশন
  // ওভাররাইট এমনিতেই হয়ে যাবে, কিন্তু ট্যাগগুলো পরিষ্কার রাখা ভালো অভ্যাস)
  injectedScriptEls.forEach(el => el.remove());
  injectedScriptEls = [];
  stage.className = "stage"; // ক্লাস রিসেট
  stage.innerHTML = "";

  // ধাপ ৪: নতুন মডিউলের manifest পড়ে HTML + script গুলো ক্রমান্বয়ে বসানো
  const base = `modules/${tabKey}/`;
  try {
    const manifest = await fetch(base + "manifest.json").then(r => r.json());

    const html = await fetch(base + manifest.panel).then(r => r.text());
    stage.innerHTML = html;

    // এই ট্যাবে আগে কিছু লেখা থাকলে, সেটা আবার বসিয়ে দেওয়া
    if (valueCache[tabKey]) {
      Object.entries(valueCache[tabKey]).forEach(([id, val]) => {
        const el = stage.querySelector(`#${id}`);
        if (el) el.value = val;
      });
    }

    for (const scriptName of manifest.scripts) {
      const el = await loadScriptSequential(base + scriptName);
      injectedScriptEls.push(el);
    }
  } catch (err) {
    stage.innerHTML = `<p style="color:red; text-align:center; padding:40px;">লোড করতে সমস্যা হয়েছে: ${err.message}</p>`;
    console.error(err);
  }

  // ধাপ ৫: এন্ট্রি অ্যানিমেশন — আগে অফ-পজিশনে বসিয়ে, এক ফ্রেম পরে "settled"-এ আনা
  // (দুটো ভিন্ন অবস্থার মধ্যে transition ঘটাতেই এই দুই-ধাপ পদ্ধতি দরকার)
  stage.classList.add(movingRight ? "enter-right" : "enter-left");
  void stage.offsetWidth; // ফোর্স রিফ্লো — ব্রাউজারকে আগের অবস্থাটা "রেজিস্টার" করাতে বাধ্য করা
  requestAnimationFrame(() => {
    stage.classList.remove("enter-left", "enter-right");
    stage.classList.add("settled");
  });

  // ধাপ ৬: ট্যাব বাটনের active স্টাইল আপডেট
  tabButtons.forEach(btn => {
    btn.classList.toggle("activeMode", btn.dataset.tab === tabKey);
  });

  currentTab = tabKey;
  document.body.setAttribute('data-tab', tabKey);
  var _ab = document.querySelector('#tabbar .activeMode'); if (_ab && _ab.scrollIntoView) { try { _ab.scrollIntoView({inline:'center', block:'nearest', behavior:'smooth'}); } catch(e){} }
  history.replaceState(null, "", `#${tabKey}`);
}

tabButtons.forEach(btn => {
  btn.addEventListener("click", () => activateTab(btn.dataset.tab));
});

// পেজ লোডে URL হ্যাশ অনুযায়ী, নাহলে প্রথম ট্যাব
const initial = location.hash.replace("#", "");
activateTab(TABS.includes(initial) ? initial : TABS[0]);
