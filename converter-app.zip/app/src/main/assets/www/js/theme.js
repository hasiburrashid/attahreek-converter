const currentTheme = localStorage.getItem('okkhortheme');
document.documentElement.setAttribute('data-theme', currentTheme);

const currentMeta = localStorage.getItem('okkhormeta');
var metaColor = document.querySelector("meta[name=theme-color]");
metaColor.setAttribute("content", currentMeta);

if (localStorage.getItem("okkhormeta") === null) {
  metaColor.setAttribute("content", '#FF6600');
};

function themeA() {
  document.documentElement.setAttribute('data-theme', 'themeA');
  localStorage.setItem('okkhortheme', 'themeA');
  metaColor.setAttribute("content", '#FF6600');
  localStorage.setItem('okkhormeta', '#FF6600');
};

function themeB() {
  document.documentElement.setAttribute('data-theme', 'themeB');
  localStorage.setItem('okkhortheme', 'themeB');
  metaColor.setAttribute("content", '#99CC00');
  localStorage.setItem('okkhormeta', '#99CC00');
};

function themeC() {
  document.documentElement.setAttribute('data-theme', 'themeC');
  localStorage.setItem('okkhortheme', 'themeC');
  metaColor.setAttribute("content", '#0099CC');
  localStorage.setItem('okkhormeta', '#0099CC');
};

function themeD() {
  document.documentElement.setAttribute('data-theme', 'themeD');
  localStorage.setItem('okkhortheme', 'themeD');
  metaColor.setAttribute("content", '#DD0099');
  localStorage.setItem('okkhormeta', '#DD0099');
};

function themeE() {
  document.documentElement.setAttribute('data-theme', 'themeE');
  localStorage.setItem('okkhortheme', 'themeE');
  metaColor.setAttribute("content", '#FFCC00');
  localStorage.setItem('okkhormeta', '#FFCC00');
};

function themeF() {
  document.documentElement.setAttribute('data-theme', 'themeF');
  localStorage.setItem('okkhortheme', 'themeF');
  metaColor.setAttribute("content", '#00CC99');
  localStorage.setItem('okkhormeta', '#00CC99');
};

function myFunction() {
   var element = document.getElementById("themeBOX");
   element.classList.toggle("themeboxact");
}



var messengerPlugin = "<div class='fb-customerchat' attribution=setup_tool page_id='100177644711708' id='messengerColor' theme_color='#FF6600'></div>";

if (localStorage.getItem("okkhormeta") == 'themeA') {
  messengerPlugin = "<div class='fb-customerchat' attribution=setup_tool page_id='100177644711708' id='messengerColor' theme_color='#FF6600'></div>";
} else if (localStorage.getItem('okkhortheme') == 'themeB') {
  messengerPlugin = "<div class='fb-customerchat' attribution=setup_tool page_id='100177644711708' id='messengerColor' theme_color='#99CC00'></div>";
} else if (localStorage.getItem('okkhortheme') == 'themeC') {
  messengerPlugin = "<div class='fb-customerchat' attribution=setup_tool page_id='100177644711708' id='messengerColor' theme_color='#0099CC'></div>";
} else if (localStorage.getItem('okkhortheme') == 'themeD') {
  messengerPlugin = "<div class='fb-customerchat' attribution=setup_tool page_id='100177644711708' id='messengerColor' theme_color='#DD0099'></div>";
} else if (localStorage.getItem('okkhortheme') == 'themeE') {
  messengerPlugin = "<div class='fb-customerchat' attribution=setup_tool page_id='100177644711708' id='messengerColor' theme_color='#FFCC00'></div>";
} else if (localStorage.getItem('okkhortheme') == 'themeF') {
  messengerPlugin = "<div class='fb-customerchat' attribution=setup_tool page_id='100177644711708' id='messengerColor' theme_color='#00CC99'></div>";
} else {
  messengerPlugin = "<div class='fb-customerchat' attribution=setup_tool page_id='100177644711708' id='messengerColor' theme_color='#FF6600'></div>";
}