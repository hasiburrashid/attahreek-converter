function openNav() {
    document.getElementById("mySidenav").classList.add("navopen");
}

function closeNav() {
    document.getElementById("mySidenav").classList.remove("navopen");
}