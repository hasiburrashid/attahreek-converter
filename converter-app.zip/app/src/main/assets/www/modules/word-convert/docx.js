/**
 * docx.js
 * -------
 * .docx ফাইল (আসলে একটা ZIP আর্কাইভ) নিয়ে, ভেতরের word/document.xml সহ
 * header/footer/footnote/endnote XML গুলোর মধ্যে থাকা <w:t> টেক্সট কনভার্ট করে,
 * ফরম্যাটিং (bold/italic/table/image/layout) অক্ষুণ্ন রেখে নতুন .docx তৈরি করে।
 *
 * মূল কৌশল:
 *  ১. XML-এর <w:r> (run) হলো ফরম্যাটিং-এর সবচেয়ে ছোট একক। আমরা পুরো প্যারাগ্রাফ
 *     না ছুঁয়ে শুধু প্রতিটা <w:t> নোডের ভেতরের টেক্সট বদলাই — তাই bold/italic/font-size
 *     ইত্যাদি অক্ষুণ্ন থাকে।
 *  ২. (ইঞ্জিন) কনভার্শন আসে Engines.get(engineKey) থেকে — js/engine-core.js (আসল /modules/* এর
 *     রেকর্ড করা চেইন, tools/regress.js দিয়ে আসলের সাথে হুবহু মেলানো)।
 *  ৩. Bijoy টাইপ করার সময় প্রায়ই একই শব্দ একাধিক <w:r>-এ ভেঙে যায় (spell-check/autocorrect
 *     এর কারণে), যদিও তাদের ফরম্যাটিং একই। এতে matra/juktakkhor ভুল বসতে পারে।
 *     তাই কনভার্টের আগে, একই ফরম্যাটিং-এর পাশাপাশি থাকা <w:r> গুলো মার্জ করে নেওয়া হয়।
 */

const WNS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';

const DocxConverter = (() => {

  // ডিফল্ট Bijoy ফন্টের নামের তালিকা (case-insensitive, partial match)
  const DEFAULT_BIJOY_FONTS = [
    'sutonnymj', 'sutonny', 'sutonnyomj', 'bijoy', 'ekushey', 'eyekar',
    'nikosh', 'sonar bangla', 'adarsha lipi', 'lohit bengali bijoy',
    'proshika', 'shishu', 'borno', 'kongsho'
  ];

  // ডিফল্ট Unicode বাংলা ফন্টের নামের তালিকা (Unicode -> Bijoy দিকের জন্য, filter এ ব্যবহৃত)
  const DEFAULT_UNICODE_FONTS = [
    'solaimanlipi', 'kalpurush', 'noto sans bengali', 'noto serif bengali',
    'siyam rupali', 'atma', 'hind siliguri', 'mukti', 'lohit bengali',
    'akaash', 'apona lohit', 'ador noirit', 'bangla',
    'nikosh', 'vrinda', 'shonar bangla', 'mitra', 'bengali'
  ];

  // sourceKind: 'unicode' (ইউনিকোড → বিজয়) | 'bijoy' (বিজয় → ইউনিকোড / বিজয় ↔ বিজয়)
  function qualifiesAsFont(fontName, extraList, sourceKind) {
    if (!fontName) return false;
    const name = fontName.toLowerCase();
    const baseList = sourceKind === 'unicode' ? DEFAULT_UNICODE_FONTS : DEFAULT_BIJOY_FONTS;
    const list = baseList.concat(extraList || []);
    return list.some(f => name.includes(f.trim().toLowerCase()) && f.trim().length > 0);
  }


  // ------------------------------------------------------------------
  // স্টাইল-রেজোলিউশন (styles.xml) — রানে সরাসরি লেখা নেই এমন ফন্ট/সাইজ/বোল্ড/ইটালিক
  // বের করতে (রান → ক্যারেক্টার স্টাইল → প্যারাগ্রাফ স্টাইল → ডিফল্ট স্টাইল → docDefaults)
  // ------------------------------------------------------------------
  function buildStyleIndex(stylesDoc) {
    const idx = { styles: {}, defaults: null, defaultPara: null };
    if (!stylesDoc) return idx;
    Array.from(stylesDoc.getElementsByTagNameNS(WNS, 'style')).forEach(st => {
      const id = st.getAttributeNS(WNS, 'styleId');
      const type = st.getAttributeNS(WNS, 'type');
      const basedOn = st.getElementsByTagNameNS(WNS, 'basedOn')[0];
      const rPr = Array.from(st.childNodes).find(n => n.localName === 'rPr' && n.namespaceURI === WNS) || null;
      idx.styles[id] = { rPr, basedOn: basedOn ? basedOn.getAttributeNS(WNS, 'val') : null, type };
      if (type === 'paragraph' && st.getAttributeNS(WNS, 'default') === '1') idx.defaultPara = id;
    });
    const dd = stylesDoc.getElementsByTagNameNS(WNS, 'docDefaults')[0];
    if (dd) {
      const rd = dd.getElementsByTagNameNS(WNS, 'rPr')[0];
      idx.defaults = rd || null;
    }
    return idx;
  }

  function childEl(parent, name) {
    return Array.from(parent.childNodes).find(n => n.localName === name && n.namespaceURI === WNS) || null;
  }

  function styleChainRPrs(idx, styleId) {
    const out = []; const seen = {};
    while (styleId && idx.styles[styleId] && !seen[styleId]) {
      seen[styleId] = true;
      if (idx.styles[styleId].rPr) out.push(idx.styles[styleId].rPr);
      styleId = idx.styles[styleId].basedOn;
    }
    return out;
  }

  /** একটা রানের "কার্যকর" rPr-গুলোর তালিকা, অগ্রাধিকার অনুযায়ী */
  function effectiveRPrs(run, paragraph, idx) {
    const list = [];
    const own = childEl(run, 'rPr');
    if (own) {
      list.push(own);
      const rs = childEl(own, 'rStyle');
      if (rs) styleChainRPrs(idx, rs.getAttributeNS(WNS, 'val')).forEach(x => list.push(x));
    }
    let pStyle = null;
    const pPr = paragraph ? childEl(paragraph, 'pPr') : null;
    if (pPr) { const ps = childEl(pPr, 'pStyle'); if (ps) pStyle = ps.getAttributeNS(WNS, 'val'); }
    styleChainRPrs(idx, pStyle || idx.defaultPara).forEach(x => list.push(x));
    if (idx.defaults) list.push(idx.defaults);
    return list;
  }

  function findEffective(list, tag) {
    for (const rPr of list) { const e = childEl(rPr, tag); if (e) return e; }
    return null;
  }

  /** rFonts এর একটা অ্যাট্রিবিউট (ascii/hAnsi/cs/eastAsia) এর কার্যকর মান (রান বা স্টাইল থেকে) */
  function effectiveFontAttr(list, attr) {
    for (const rPr of list) {
      const rf = childEl(rPr, 'rFonts');
      if (rf && rf.getAttributeNS(WNS, attr)) return rf.getAttributeNS(WNS, attr);
    }
    return '';
  }

  const RPR_ORDER = ['rStyle', 'rFonts', 'b', 'bCs', 'i', 'iCs', 'caps', 'smallCaps', 'strike', 'dstrike',
    'outline', 'shadow', 'emboss', 'imprint', 'noProof', 'snapToGrid', 'vanish', 'webHidden', 'color',
    'spacing', 'w', 'kern', 'position', 'sz', 'szCs', 'highlight', 'u', 'effect', 'bdr', 'shd', 'fitText',
    'vertAlign', 'rtl', 'cs', 'em', 'lang', 'eastAsianLayout', 'specVanish', 'oMath'];

  /** rPr এ স্কিমা-ক্রম মেনে একটা চাইল্ড বসায় (আগের একই নামের এলিমেন্ট থাকলে বদলে দেয়) */
  function putRPrChild(doc, rPr, tag, srcEl) {
    const old = childEl(rPr, tag);
    const el = doc.createElementNS(WNS, 'w:' + tag);
    if (srcEl) Array.from(srcEl.attributes).forEach(a => {
      if (a.namespaceURI === WNS) el.setAttributeNS(WNS, 'w:' + a.localName, a.value);
    });
    if (old) { rPr.replaceChild(el, old); return; }
    const myPos = RPR_ORDER.indexOf(tag);
    const before = Array.from(rPr.childNodes).find(n => {
      const pos = RPR_ORDER.indexOf(n.localName);
      return pos > myPos;
    });
    if (before) rPr.insertBefore(el, before); else rPr.appendChild(el);
  }

  function removeRPrChild(rPr, tag) {
    const old = childEl(rPr, tag);
    if (old) rPr.removeChild(old);
  }

  /**
   * বাংলা ইউনিকোড একটা "complex script": Word তার সাইজ/বোল্ড/ইটালিক নেয় w:szCs / w:bCs / w:iCs থেকে।
   * আর বিজয় (ASCII) লেখা নেয় w:sz / w:b / w:i থেকে। তাই ফন্ট বদলানোর সাথে এই জোড়াগুলোও
   * মিলিয়ে না দিলে সাইজ ও বোল্ড/ইটালিক এলোমেলো হয়ে যায় (কোথাও বড়, কোথাও ছোট)।
   *   toUnicode: sz→szCs, b→bCs, i→iCs      toBijoy: szCs→sz, bCs→b, iCs→i
   */
  function syncScriptProps(doc, run, paragraph, idx, toUnicode) {
    const pairs = toUnicode
      ? [['sz', 'szCs'], ['b', 'bCs'], ['i', 'iCs']]
      : [['szCs', 'sz'], ['bCs', 'b'], ['iCs', 'i']];
    const list = effectiveRPrs(run, paragraph, idx);
    let rPr = childEl(run, 'rPr');
    if (!rPr) {
      rPr = doc.createElementNS(WNS, 'w:rPr');
      run.insertBefore(rPr, run.firstChild);
    }
    for (const [srcTag, dstTag] of pairs) {
      const src = findEffective(list, srcTag);
      const dst = findEffective(list, dstTag);
      if (src) {
        putRPrChild(doc, rPr, dstTag, src);
      } else if (dst && (dstTag === 'b' || dstTag === 'i' || dstTag === 'bCs' || dstTag === 'iCs')) {
        // মূল লেখা বোল্ড/ইটালিক ছিল না, কিন্তু গন্তব্য-স্ক্রিপ্টের স্টাইলে আছে — স্পষ্টভাবে বন্ধ করা
        const off = doc.createElementNS(WNS, 'w:' + dstTag);
        off.setAttributeNS(WNS, 'w:val', '0');
        putRPrChild(doc, rPr, dstTag, off);
      }
    }
    if (!toUnicode) { removeRPrChild(rPr, 'cs'); removeRPrChild(rPr, 'rtl'); }
  }

  const BENGALI_RE = /[ঀ-৿।॥]/;

  const NON_TEXT_TAGS = ['br', 'tab', 'drawing', 'noBreakHyphen', 'footnoteReference',
    'endnoteReference', 'commentReference', 'object', 'pict', 'fldChar', 'instrText'];

  function isSimpleTextRun(run) {
    const tNodes = run.getElementsByTagNameNS(WNS, 't');
    if (tNodes.length !== 1) return false;
    return !NON_TEXT_TAGS.some(tag => run.getElementsByTagNameNS(WNS, tag).length > 0);
  }

  /**
   * একটা প্যারাগ্রাফের সব রান (হাইপারলিংক/ins/del এর ভেতরে নেস্টেড থাকলেও) ধারাবাহিকভাবে
   * প্রসেস করে। পাশাপাশি "যোগ্য" (simple-text + ফন্ট-ফিল্টার পাস করা) রান-গুলোকে একটা
   * গ্রুপ হিসেবে ধরে, তাদের টেক্সট একসাথে জোড়া দিয়ে (concatenate) ইঞ্জিন দিয়ে
   * এক-পাসে ম্যাচ করানো হয় — এতে কোনো Bijoy প্যাটার্ন দুই রানের মাঝে ভেঙে গেলেও সঠিকভাবে
   * ম্যাচ হয় (রান-বাউন্ডারিতে ফরম্যাটিং যা-ই থাকুক না কেন)। এরপর প্রতিটা ম্যাচড অংশ যে
   * রান থেকে শুরু হয়েছে, সেই রানেই তার আউটপুট বসিয়ে দেওয়া হয় — মূল রান নোডগুলো (এবং তাদের
   * প্যারেন্ট যেমন hyperlink) অক্ষতই থাকে, শুধু ভেতরের টেক্সট বদলায়।
   */
  function processParagraph(paragraph, options, ctx) {
    const runs = Array.from(paragraph.getElementsByTagNameNS(WNS, 'r'));
    const sourceKind = options.sourceKind === 'unicode' ? 'unicode' : 'bijoy';
    const engine = Engines.get(options.engineKey);

    const idx = options.styleIndex || buildStyleIndex(null);

    function qualifies(run) {
      if (!isSimpleTextRun(run)) return false;
      if (!options.filterByFont) return true;
      const list = effectiveRPrs(run, paragraph, idx);
      const names = ['ascii', 'hAnsi', 'cs', 'eastAsia'].map(a => effectiveFontAttr(list, a)).filter(Boolean);
      if (sourceKind === 'unicode') {
        // ইউনিকোড বাংলা Word এ সাধারণত w:cs ফন্টে থাকে (ascii ফন্ট Times New Roman হলেও) — তাই চারটার যেকোনোটা মিললেই চলবে।
        // ফন্ট চেনা না গেলেও রানে বাংলা অক্ষর থাকলেই ধরা হয় (একাধিক ইউনিকোড ফন্ট/থিম-ফন্ট/স্টাইল-ইনহেরিটেড ফন্ট সামলাতে)।
        if (names.some(n => qualifiesAsFont(n, options.matchFonts, sourceKind))) return true;
        const t = run.getElementsByTagNameNS(WNS, 't')[0];
        return !!t && BENGALI_RE.test(t.textContent);
      }
      // বিজয়: ASCII টেক্সট ascii/hAnsi ফন্টে রেন্ডার হয়
      const name = effectiveFontAttr(list, 'ascii') || effectiveFontAttr(list, 'hAnsi') || names[0] || '';
      return qualifiesAsFont(name, options.matchFonts, sourceKind);
    }

    let i = 0;
    while (i < runs.length) {
      if (!qualifies(runs[i])) { i++; continue; }

      // consecutive qualifying runs -> one matching group
      const group = [];
      let j = i;
      while (j < runs.length && qualifies(runs[j])) { group.push(runs[j]); j++; }

      const tNodesOfGroup = group.map(r => r.getElementsByTagNameNS(WNS, 't')[0]);
      const runLengths = tNodesOfGroup.map(t => t.textContent.length);
      const offsets = [];
      let acc = 0;
      for (const l of runLengths) { offsets.push(acc); acc += l; }
      const fullText = tNodesOfGroup.map(t => t.textContent).join('');

      if (fullText.length > 0) {
        // আসল সাইটে পুরো ডকুমেন্ট একটাই টেক্সটবক্স, প্যারাগ্রাফ "\n" দিয়ে আলাদা। তাই প্যারাগ্রাফ (বা
        // লাইন-ব্রেকের) শুরুতে ভার্চুয়াল "\n" বসানো হয় — শুধু ফাইলের একদম প্রথম টেক্সটে নয়।
        const startsLine = i === 0 || (runs[i - 1].getElementsByTagNameNS(WNS, 'br').length > 0);
        const matches = engine.getMatches(fullText, { paragraphStart: ctx.started && startsLine });
        ctx.started = true;
        const outputBuffers = new Array(group.length).fill('');

        // প্রতিটা ম্যাচড স্প্যান কোন রান থেকে শুরু হয়েছে সেটা বের করে সেই রানের বাফারে যোগ করা
        let runCursor = 0;
        for (const m of matches) {
          while (runCursor < group.length - 1 && m.start >= offsets[runCursor] + runLengths[runCursor]) {
            runCursor++;
          }
          outputBuffers[runCursor] += m.replacement;
        }

        let anyChanged = false;
        for (let k = 0; k < group.length; k++) {
          const original = tNodesOfGroup[k].textContent;
          const converted = outputBuffers[k];
          if (converted !== original) {
            tNodesOfGroup[k].textContent = converted;
            tNodesOfGroup[k].setAttribute('xml:space', 'preserve');
            anyChanged = true;
          }
        }

        if (anyChanged && options.targetFont && !options.keepFont) {
          const doc = paragraph.ownerDocument;
          group.forEach(run => {
            setRunFont(doc, run, options.targetFont);
            syncScriptProps(doc, run, paragraph, idx, sourceKind === 'bijoy');
          });
        }
      }

      i = j;
    }

    // delText (tracked-changes deleted text) — এককভাবে কনভার্ট করা হয় (গ্রুপিং ছাড়া, বিরল এজ-কেস)
    const delRuns = runs.filter(r => r.getElementsByTagNameNS(WNS, 'delText').length > 0);
    for (const run of delRuns) {
      if (options.filterByFont && !qualifiesAsFont(getRunFontName(run), options.matchFonts, sourceKind)) continue;
      const delT = run.getElementsByTagNameNS(WNS, 'delText')[0];
      const converted = engine.convertText(delT.textContent);
      if (converted !== delT.textContent) {
        delT.textContent = converted;
        delT.setAttribute('xml:space', 'preserve');
      }
    }
  }

  /**
   * একটা রানের <w:rPr><w:rFonts> এ target ফন্ট বসায়।
   * rFonts না থাকলে নতুন তৈরি করে।
   */
  function setRunFont(doc, run, fontName) {
    let rPr = run.getElementsByTagNameNS(WNS, 'rPr')[0];
    if (!rPr) {
      rPr = doc.createElementNS(WNS, 'w:rPr');
      run.insertBefore(rPr, run.firstChild);
    }
    let rFonts = rPr.getElementsByTagNameNS(WNS, 'rFonts')[0];
    if (!rFonts) {
      rFonts = doc.createElementNS(WNS, 'w:rFonts');
      const rStyle = Array.from(rPr.childNodes).find(n => n.localName === 'rStyle');
      if (rStyle && rStyle.nextSibling) rPr.insertBefore(rFonts, rStyle.nextSibling);
      else if (rStyle) rPr.appendChild(rFonts);
      else rPr.insertBefore(rFonts, rPr.firstChild);
    }
    // থিম-ফন্ট অ্যাট্রিবিউট থাকলে Word সেটাকেই অগ্রাধিকার দেয় — সরিয়ে ফেলা
    ['asciiTheme', 'hAnsiTheme', 'eastAsiaTheme', 'cstheme', 'hint'].forEach(a => {
      if (rFonts.hasAttributeNS(WNS, a)) rFonts.removeAttributeNS(WNS, a);
    });
    ['w:ascii', 'w:hAnsi', 'w:cs', 'w:eastAsia'].forEach(attr => {
      rFonts.setAttribute(attr, fontName);
    });
  }

  function getRunFontName(run) {
    const rFonts = run.getElementsByTagNameNS(WNS, 'rFonts')[0];
    if (!rFonts) return '';
    return rFonts.getAttribute('w:ascii') || rFonts.getAttribute('w:hAnsi') ||
      rFonts.getAttribute('w:cs') || rFonts.getAttribute('w:eastAsia') || '';
  }

  /**
   * একটা XML স্ট্রিং (document.xml / header*.xml / footer*.xml ইত্যাদি) প্রসেস করে
   * কনভার্টেড XML স্ট্রিং রিটার্ন করে।
   *
   * options:
   *   engineKey: 'u2b-2003' | 'u2b-classic' | 'b2u-2003' | 'b2u-classic' | 'b2b-2003-classic' | 'b2b-classic-2003'
   *   sourceKind: 'unicode' | 'bijoy' — সোর্স টেক্সট কোন ধরনের ফন্টে আছে (ফন্ট-ফিল্টারের তালিকা এটা ঠিক করে)
   *   filterByFont: boolean — true হলে শুধু matchFonts/ডিফল্ট তালিকার সাথে মিলে যাওয়া রান কনভার্ট হবে
   *   matchFonts: string[] — অতিরিক্ত ফন্টের নাম (ইউজার ইনপুট থেকে)
   *   targetFont: string — কনভার্টের পর যে ফন্ট বসানো হবে
   *   keepFont: boolean — true হলে ফন্টের নাম বদলানো হয় না (বিজয় ↔ বিজয়)
   */
  function processXml(xmlString, options) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(xmlString, 'application/xml');

    const errorNode = doc.getElementsByTagName('parsererror')[0];
    if (errorNode) {
      throw new Error('XML পার্স করতে সমস্যা হয়েছে: ' + errorNode.textContent.slice(0, 200));
    }

    // প্রতিটা XML ফাইলের (document.xml/header.xml/...) জন্য একটা fresh ctx — "ফাইলের প্রথম টেক্সট"
    // চেনার জন্য (শুধু সেটারই আগে "\n" থাকে না; দেখুন processParagraph)
    const ctx = { started: false };

    // প্রতিটা প্যারাগ্রাফ ধরে ধরে প্রসেস করা — গ্রুপিং, ম্যাচিং, রান-এ ফিরিয়ে বসানো সব এক ফাংশনে
    const paragraphs = Array.from(doc.getElementsByTagNameNS(WNS, 'p'));
    paragraphs.forEach(p => processParagraph(p, options, ctx));

    return new XMLSerializer().serializeToString(doc);
  }

  /**
   * মূল ফাংশন: একটা .docx ফাইল (File/Blob) নিয়ে কনভার্টেড .docx এর Blob রিটার্ন করে।
   * onProgress(message) কলব্যাক দিয়ে UI তে স্ট্যাটাস দেখানো যায়।
   */
  async function convertDocx(file, options, onProgress) {
    onProgress && onProgress('ফাইল আনজিপ করা হচ্ছে...');
    let zip;
    try {
      zip = await JSZip.loadAsync(file);
    } catch (e) {
      throw new Error('ফাইলটি বৈধ .docx নয় (ভাঙা, পাসওয়ার্ড-দেওয়া বা অন্য ফরম্যাটের ফাইল হতে পারে)।');
    }

    const targetPathPattern = /^word\/(document|header\d*|footer\d*|footnotes|endnotes)\.xml$/;
    const targets = Object.keys(zip.files).filter(name => targetPathPattern.test(name));

    if (targets.length === 0) {
      throw new Error('এটা একটা বৈধ .docx ফাইল বলে মনে হচ্ছে না (word/document.xml পাওয়া যায়নি)।');
    }

    // styles.xml থেকে ফন্ট/সাইজ ইনহেরিট্যান্স বুঝতে স্টাইল-ইনডেক্স
    let styleIndex = buildStyleIndex(null);
    const stylesFile = zip.file('word/styles.xml');
    if (stylesFile) {
      try {
        const sd = new DOMParser().parseFromString(await stylesFile.async('string'), 'application/xml');
        if (!sd.getElementsByTagName('parsererror')[0]) styleIndex = buildStyleIndex(sd);
      } catch (e) { /* স্টাইল না পড়া গেলে শুধু রানের নিজস্ব তথ্য দিয়ে চলবে */ }
    }
    options = Object.assign({}, options, { styleIndex });

    for (const path of targets) {
      onProgress && onProgress(`কনভার্ট করা হচ্ছে: ${path}`);
      const xmlString = await zip.file(path).async('string');
      await new Promise(r => setTimeout(r, 0)); // UI (স্পিনার) যেন আটকে না যায়
      const converted = processXml(xmlString, options);
      zip.file(path, converted);
    }

    onProgress && onProgress('নতুন .docx ফাইল তৈরি করা হচ্ছে...');
    const blob = await zip.generateAsync({
      type: 'blob',
      mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    });
    return blob;
  }

  return { convertDocx, processXml, DEFAULT_BIJOY_FONTS, DEFAULT_UNICODE_FONTS };
})();
