/**
 * app.js — UI ওয়্যারিং: ৩-ধাপ মোড সিলেক্টর, মাল্টি-ফাইল তালিকা, সেটিংস, কনভার্ট,
 * এবং একে একে ডাউনলোড (কোনো zip নয়, ফোল্ডার বাছাই লাগে না)।
 */
(function () {
  'use strict';

  // ---------------- মোড টেবিল ----------------
  // key = Engines.get(key) এর ইঞ্জিন (js/engine-data.js)
  const MODES = {
    u2b: {
      sourceKind: 'unicode',
      subs: [
        { key: 'u2b-2003', label: 'ইউনিকোড টু বিজয় (২০০৩)', suffix: '-bijoy2003', target: 'bijoy' },
        { key: 'u2b-classic', label: 'ইউনিকোড টু বিজয় (ক্লাসিক)', suffix: '-bijoy-classic', target: 'bijoy' }
      ]
    },
    b2u: {
      sourceKind: 'bijoy',
      subs: [
        { key: 'b2u-2003', label: 'বিজয় (২০০৩) টু ইউনিকোড', suffix: '-unicode', target: 'unicode' },
        { key: 'b2u-classic', label: 'বিজয় (ক্লাসিক) টু ইউনিকোড', suffix: '-unicode', target: 'unicode' }
      ]
    },
    b2b: {
      sourceKind: 'bijoy',
      subs: [
        { key: 'b2b-2003-classic', label: 'বিজয় (২০০৩) টু বিজয় (ক্লাসিক)', suffix: '-bijoy-classic', target: null },
        { key: 'b2b-classic-2003', label: 'বিজয় (ক্লাসিক) টু বিজয় (২০০৩)', suffix: '-bijoy2003', target: null }
      ]
    }
  };

  const SOURCE_TEXT = {
    unicode: {
      filterLabel: 'শুধু ইউনিকোড ফন্টের লেখা কনভার্ট হবে (বাকি ইংরেজি/আরবী লেখা অক্ষুণ্ণ থাকবে)',
      fontListLabel: 'ইউনিকোড ফন্ট নির্বাচন করুন (ব্যতিক্রম থাকলে কমা দিয়ে লিখুন)। যেমন :',
      fontListPlaceholder: 'Nikosh, SolaimanLipi, Kalpurush ',
      fontListHint: 'সাধারণ কিছু ইউনিকোড ফন্ট (Nikosh, SolaimanLipi, Kalpurush, SutonnyOMJ) আগে থেকেই যুক্ত আছে। ফাইলের লেখা এসব ফন্টে থাকলে নতুন করে যুক্ত করার প্রয়োজন নেই।'
    },
    bijoy: {
      filterLabel: 'শুধু বিজয় ফন্টের লেখা কনভার্ট হবে (বাকি ইংরেজি/আরবী লেখা অক্ষুণ্ণ থাকবে)',
      fontListLabel: 'বিজয় ফন্ট নির্বাচন করুন (একাধিক হ’লে কমা দিয়ে লিখুন)। যেমন :',
      fontListPlaceholder: 'SutonnyMJ, KongshoMJ ',
      fontListHint: 'সাধারণ বিজয় ফন্ট (SutonnyMJ) আগে থেকেই যুক্ত আছে। কনভার্টের পর লেখাটি এই ফন্টে হবে। এই ফন্ট ইনস্টল না থাকলে সঠিক দেখাবে না।'
    }
  };
  const FILTER_HINT = 'এটি বন্ধ করলে ডকুমেন্টের সব টেক্সট কনভার্ট হবে। ইংরেজি বা অন্য ফন্টের লেখা থাকলে সেটাও ভেঙে যেতে পারে, তাই সাধারণত এটি চালু রাখাই নিরাপদ।';

  const TARGET_TEXT = {
    unicode: {
      label: ' ইউনিকোড ফন্ট নির্বাচন করুন :',
      hint: 'এই ফন্ট ইনস্টল না থাকলে লেখা ডিফল্ট বাংলা ফন্টে দেখাবে।',
      options: ['SolaimanLipi', 'Nikosh', 'Kalpurush', 'Noto Sans Bengali', 'Siyam Rupali'],
      defaultFont: 'Nikosh'
    },
    bijoy: {
      label: ' বিজয় (ASCII) ফন্ট নির্বাচন করুন :',
      hint: 'কনভার্টের পর লেখাটি এই ফন্টে হবে। এই ফন্ট ইনস্টল না থাকলে লেখা সঠিক দেখাবে না।',
      options: ['SutonnyMJ'],
      defaultFont: 'SutonnyMJ'
    }
  };

  function $(id) { return document.getElementById(id); }

  function init() {
    const el = {
      typeRow: $('typeModeRow'), subRow: $('subModeRow'),
      docNote: $('docNote'), docNoteLink: $('docNoteLink'), docNoteLinkText: $('docNoteLinkText'),
      dropzone: $('dropzone'), fileInput: $('fileInput'), browseBtn: $('browseBtn'),
      fileListWrap: $('fileListWrap'), fileList: $('fileList'), fileCount: $('fileCount'),
      clearAllBtn: $('clearAllBtn'), fileWarning: $('fileWarning'),
      toggleSettings: $('toggleSettings'), settingsPanel: $('settingsPanel'),
      filterByFont: $('filterByFont'), filterByFontLabel: $('filterByFontLabel'), filterByFontHint: $('filterByFontHint'),
      fontListRow: $('fontListRow'), fontListInput: $('fontListInput'), fontListLabel: $('fontListLabel'), fontListHint: $('fontListHint'),
      targetFontRow: $('targetFontRow'), targetFontInput: $('targetFontInput'), targetFontLabel: $('targetFontLabel'), targetFontHint: $('targetFontHint'),
      convertBtn: $('convertBtn'), logCard: $('logCard'), logOutput: $('logOutput'),
      resultCard: $('resultCard'), resultTitle: $('resultTitle'), resultSub: $('resultSub'), resultList: $('resultList'),
      saveFolderBtn: $('saveFolderBtn'), saveNote: $('saveNote'), convertAnotherBtn: $('convertAnotherBtn')
    };
    const missing = Object.keys(el).filter(k => !el[k]);
    if (missing.length) {
      console.error('[কনভার্টার] পেজে এই এলিমেন্টগুলো পাওয়া যায়নি: ' + missing.join(', '));
      return;
    }

    const cfg = (window.CONVERTER_CONFIG && window.CONVERTER_CONFIG.docToDocx) || {};
    let type = 'u2b';          // ডিফল্ট: প্রথম বাটন
    let subIndex = 0;          // এবং তার প্রথম উপ-বাটন
    let files = [];            // { id, file, status, blob, outName, error }
    let nextId = 1;
    let busy = false;

    const currentSub = () => MODES[type].subs[subIndex];

    // ---------------- .doc → .docx নোট (config থেকে) ----------------
    if (!cfg.url) {
      el.docNoteLink.hidden = true;
    } else {
      el.docNoteLink.href = cfg.url;
      if (cfg.label) el.docNoteLinkText.textContent = cfg.label;
      if (cfg.newTab === false) { el.docNoteLink.removeAttribute('target'); el.docNoteLink.removeAttribute('rel'); }
    }

    // ---------------- মোড সিলেক্টর ----------------
    function renderSubRow() {
      el.subRow.innerHTML = '';
      MODES[type].subs.forEach((s, i) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'direction-btn' + (i === subIndex ? ' active' : '');
        b.setAttribute('role', 'tab');
        b.setAttribute('aria-selected', String(i === subIndex));
        b.dataset.key = s.key;
        b.textContent = s.label;
        el.subRow.appendChild(b);
      });
    }

    function renderTypeRow() {
      Array.from(el.typeRow.children).forEach(tab => {
        const on = tab.dataset.type === type;
        tab.classList.toggle('active', on);
        tab.setAttribute('aria-selected', String(on));
      });
    }

    function applySettingsText() {
      const m = MODES[type];
      const sub = currentSub();
      const t = SOURCE_TEXT[m.sourceKind];
      el.filterByFontLabel.textContent = t.filterLabel;
      el.filterByFontHint.textContent = FILTER_HINT;
      el.fontListLabel.textContent = t.fontListLabel;
      el.fontListInput.placeholder = t.fontListPlaceholder;
      el.fontListHint.textContent = t.fontListHint;
      el.fontListRow.hidden = !el.filterByFont.checked;

      if (sub.target) {
        const tt = TARGET_TEXT[sub.target];
        el.targetFontRow.hidden = false;
        el.targetFontLabel.textContent = tt.label;
        el.targetFontHint.textContent = tt.hint;
        el.targetFontInput.innerHTML = '';
        tt.options.forEach(name => {
          const o = document.createElement('option');
          o.value = name; o.textContent = name;
          if (name === tt.defaultFont) o.selected = true;
          el.targetFontInput.appendChild(o);
        });
      } else {
        // বিজয় ↔ বিজয়: ফন্টের নাম বদলানো হয় না
        el.targetFontRow.hidden = true;
      }
    }

    function resetResults() {
      el.resultCard.hidden = true;
      el.logCard.hidden = true;
      el.saveNote.hidden = true;
      files.forEach(f => { if (f.status !== 'error') { f.status = 'pending'; f.blob = null; f.outName = null; } });
      renderFiles();
    }

    function selectType(t) {
      if (busy || t === type) return;
      type = t; subIndex = 0;
      renderTypeRow(); renderSubRow(); applySettingsText(); resetResults();
    }
    function selectSub(i) {
      if (busy || i === subIndex) return;
      subIndex = i;
      renderSubRow(); applySettingsText(); resetResults();
    }

    function bindTabs(row, handler) {
      row.addEventListener('click', e => {
        const tab = e.target.closest('.direction-btn');
        if (tab && row.contains(tab)) handler(tab);
      });
    }
    bindTabs(el.typeRow, tab => selectType(tab.dataset.type));
    bindTabs(el.subRow, tab => selectSub(Array.from(el.subRow.children).indexOf(tab)));

    // ---------------- ফাইল তালিকা ----------------
    function formatSize(bytes) {
      if (bytes < 1024) return bytes + ' B';
      if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
      return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    }

    const STATUS_TEXT = { pending: 'অপেক্ষমাণ', running: 'কনভার্ট হচ্ছে…', done: 'সম্পন্ন ✓', error: '' };

    function statusNode(f) {
      const s = document.createElement('span');
      s.className = 'file-status';
      if (f.status === 'running') {
        const sp = document.createElement('span');
        sp.className = 'btn-spinner'; sp.setAttribute('aria-hidden', 'true');
        s.appendChild(sp);
      }
      s.appendChild(document.createTextNode(f.status === 'error' ? 'ব্যর্থ: ' + f.error : STATUS_TEXT[f.status]));
      return s;
    }

    function renderFiles() {
      el.fileList.innerHTML = '';
      files.forEach(f => {
        const li = document.createElement('li');
        li.className = 'is-' + f.status;
        li.dataset.id = String(f.id);
        const dot = document.createElement('span'); dot.className = 'file-dot'; dot.setAttribute('aria-hidden', 'true');
        const name = document.createElement('span'); name.className = 'file-name'; name.textContent = f.file.name;
        const size = document.createElement('span'); size.className = 'file-size'; size.textContent = formatSize(f.file.size);
        li.append(dot, name, size, statusNode(f));
        const rm = document.createElement('button');
        rm.type = 'button'; rm.className = 'icon-btn'; rm.textContent = '✕';
        rm.setAttribute('aria-label', f.file.name + ' সরিয়ে ফেলুন');
        rm.disabled = busy;
        rm.addEventListener('click', ev => { ev.stopPropagation(); removeFile(f.id); });
        li.appendChild(rm);
        el.fileList.appendChild(li);
      });
      el.fileListWrap.hidden = files.length === 0;
      el.fileCount.textContent = files.length + 'টি ফাইল নির্বাচিত';
      el.convertBtn.disabled = busy || files.length === 0;
      el.clearAllBtn.disabled = busy;
    }

    function removeFile(id) {
      if (busy) return;
      files = files.filter(f => f.id !== id);
      if (!files.some(f => f.status === 'done')) { el.resultCard.hidden = true; el.saveNote.hidden = true; }
      renderFiles();
    }

    function showWarnings(lines) {
      if (!lines.length) { el.fileWarning.hidden = true; el.fileWarning.textContent = ''; return; }
      el.fileWarning.style.whiteSpace = 'pre-line';
      el.fileWarning.textContent = lines.join('\n');
      el.fileWarning.hidden = false;
    }

    async function addFiles(list) {
      if (busy) return;
      const warnings = [];
      for (const file of Array.from(list)) {
        const lower = file.name.toLowerCase();
        if (lower.endsWith('.doc') && !lower.endsWith('.docx')) {
          if (typeof cfg.api === 'function') {
            try {
              const res = await cfg.api(file);
              const out = res instanceof File ? res : new File([res], file.name.replace(/\.doc$/i, '.docx'), { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
              pushFile(out);
              continue;
            } catch (err) {
              warnings.push('"' + file.name + '" — .docx এ রূপান্তর করা যায়নি (' + err.message + ')। উপরের লিংকে গিয়ে নিজে রূপান্তর করে নিন।');
              continue;
            }
          }
          warnings.push('"' + file.name + '" — পুরনো .doc ফাইল কনভার্ট করা যায় না। আগে .docx এ রূপান্তর করে (উপরের লিংক দেখুন) আবার দিন।');
          continue;
        }
        if (!lower.endsWith('.docx')) { warnings.push('"' + file.name + '" — শুধু .docx ফাইল সাপোর্টেড।'); continue; }
        pushFile(file);
      }
      showWarnings(warnings);
      resetResultsAfterAdd();
      renderFiles();
    }

    function pushFile(file) {
      const dup = files.some(f => f.file.name === file.name && f.file.size === file.size && f.file.lastModified === file.lastModified);
      if (dup) return;
      files.push({ id: nextId++, file, status: 'pending', blob: null, outName: null, error: '' });
    }

    function resetResultsAfterAdd() {
      el.resultCard.hidden = true; el.logCard.hidden = true; el.saveNote.hidden = true;
      files.forEach(f => { if (f.status === 'done') { f.status = 'pending'; f.blob = null; f.outName = null; } });
    }

    el.browseBtn.addEventListener('click', e => { e.stopPropagation(); el.fileInput.click(); });
    el.dropzone.addEventListener('click', e => { if (e.target === el.browseBtn) return; el.fileInput.click(); });
    el.dropzone.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.fileInput.click(); }
    });
    el.fileInput.addEventListener('change', () => {
      if (el.fileInput.files.length) addFiles(el.fileInput.files);
      el.fileInput.value = ''; // একই ফাইল আবার বাছাই করা গেলেও change ইভেন্ট আসবে
    });
    ['dragenter', 'dragover'].forEach(evt => el.dropzone.addEventListener(evt, e => {
      e.preventDefault(); el.dropzone.classList.add('dragover');
    }));
    ['dragleave', 'drop'].forEach(evt => el.dropzone.addEventListener(evt, e => {
      e.preventDefault(); el.dropzone.classList.remove('dragover');
    }));
    el.dropzone.addEventListener('drop', e => {
      if (e.dataTransfer.files.length) addFiles(e.dataTransfer.files);
    });
    el.clearAllBtn.addEventListener('click', () => {
      if (busy) return;
      files = []; showWarnings([]);
      el.resultCard.hidden = true; el.saveNote.hidden = true;
      renderFiles();
    });

    // ---------------- সেটিংস ----------------
    el.toggleSettings.addEventListener('click', () => {
      const expanded = el.toggleSettings.getAttribute('aria-expanded') === 'true';
      el.toggleSettings.setAttribute('aria-expanded', String(!expanded));
      el.settingsPanel.hidden = expanded;
    });
    el.filterByFont.addEventListener('change', () => { el.fontListRow.hidden = !el.filterByFont.checked; });

    // ---------------- কনভার্ট ----------------
    function log(message, isError) {
      const line = document.createElement('p');
      line.className = 'log-line' + (isError ? ' err' : '');
      const time = new Date().toLocaleTimeString('bn-BD', { hour12: false });
      const t = document.createElement('span'); t.className = 't'; t.textContent = time;
      line.append(t, document.createTextNode(message));
      el.logOutput.appendChild(line);
      el.logOutput.scrollTop = el.logOutput.scrollHeight;
    }

    function uniqueOutName(base, suffix, taken) {
      let name = base + suffix + '.docx', n = 2;
      while (taken.has(name.toLowerCase())) name = base + suffix + ' (' + n++ + ').docx';
      taken.add(name.toLowerCase());
      return name;
    }

    const tick = () => new Promise(r => setTimeout(r, 0));

    el.convertBtn.addEventListener('click', async () => {
      if (busy || !files.length) return;
      const sub = currentSub();
      const m = MODES[type];
      const originalLabel = el.convertBtn.textContent;
      busy = true;
      el.convertBtn.disabled = true;
      el.convertBtn.classList.add('is-loading');
      el.convertBtn.innerHTML = '<span class="btn-content"><span class="btn-spinner" aria-hidden="true"></span><span>কনভার্ট হচ্ছে…</span></span>';
      el.resultCard.hidden = true; el.saveNote.hidden = true;
      el.logOutput.innerHTML = ''; log('শুরু হচ্ছে…');

      const options = {
        engineKey: sub.key,
        sourceKind: m.sourceKind,
        filterByFont: el.filterByFont.checked,
        matchFonts: el.fontListInput.value.split(',').map(s => s.trim()).filter(Boolean),
        targetFont: sub.target ? (el.targetFontInput.value.trim() || TARGET_TEXT[sub.target].defaultFont) : '',
        keepFont: !sub.target
      };

      const taken = new Set();
      files.forEach(f => { f.status = 'pending'; f.blob = null; f.outName = null; f.error = ''; });
      renderFiles();

      for (const f of files) {
        f.status = 'running'; renderFiles();
        await tick();
        try {
          log(f.file.name + ' …');
          f.blob = await DocxConverter.convertDocx(f.file, options, msg => log(msg));
          f.outName = uniqueOutName(f.file.name.replace(/\.docx$/i, ''), sub.suffix, taken);
          f.status = 'done';
        } catch (err) {
          console.error(err);
          f.status = 'error'; f.error = err.message || String(err);
          log(f.file.name + ': ত্রুটি: ' + f.error, true);
        }
        renderFiles();
      }

      busy = false;
      el.convertBtn.classList.remove('is-loading');
      el.convertBtn.textContent = originalLabel;
      renderFiles();
      showResults();
    });

    function showResults() {
      const done = files.filter(f => f.status === 'done');
      const failed = files.filter(f => f.status === 'error');
      if (!done.length) { el.resultCard.hidden = true; return; }
      el.resultTitle.textContent = 'রূপান্তর সম্পন্ন হয়েছে';
      el.resultSub.textContent = done.length + 'টি ফাইল প্রস্তুত' + (failed.length ? ' · ' + failed.length + 'টি ব্যর্থ' : '');
      el.resultList.innerHTML = '';
      done.forEach(f => {
        const li = document.createElement('li');
        li.className = 'is-done';
        const dot = document.createElement('span'); dot.className = 'file-dot';
        const name = document.createElement('span'); name.className = 'file-name'; name.textContent = f.outName;
        const size = document.createElement('span'); size.className = 'file-size'; size.textContent = formatSize(f.blob.size);
        const dl = document.createElement('a');
        dl.textContent = 'ডাউনলোড'; dl.className = 'link-btn';
        dl.href = URL.createObjectURL(f.blob); dl.download = f.outName;
        li.append(dot, name, size, dl);
        el.resultList.appendChild(li);
      });
      el.saveFolderBtn.disabled = false;
      el.saveNote.hidden = false; el.saveNote.className = 'save-note';
      el.saveNote.textContent = 'বাটনে ক্লিক করলে সব ফাইল একে একে ডাউনলোড হবে। ব্রাউজার "একাধিক ডাউনলোডের অনুমতি" চাইলে Allow দিন।';
      el.resultCard.hidden = false;
      el.resultCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    // ---------------- ডাউনলোড (ব্রাউজারের নিজস্ব ডাউনলোড ফোল্ডারে; ফোল্ডার বাছাই লাগে না) ----------------
    el.saveFolderBtn.textContent = 'সব ফাইল ডাউনলোড করুন';

    function downloadOneByOne(done) {
      return new Promise(resolve => {
        let i = 0;
        const next = () => {
          if (i >= done.length) { resolve(); return; }
          const f = done[i++];
          const url = URL.createObjectURL(f.blob);
          const a = document.createElement('a');
          a.href = url; a.download = f.outName; a.style.display = 'none';
          document.body.appendChild(a); a.click(); a.remove();
          setTimeout(() => URL.revokeObjectURL(url), 60000);
          setTimeout(next, 1200); // Chrome এর "একাধিক ডাউনলোড" প্রম্পটের জন্য সময় দেওয়া
        };
        next();
      });
    }

    el.saveFolderBtn.addEventListener('click', async () => {
      const done = files.filter(f => f.status === 'done' && f.blob);
      if (!done.length) return;
      el.saveFolderBtn.disabled = true;
      await downloadOneByOne(done);
      el.saveNote.hidden = false;
      el.saveNote.className = 'save-note is-ok';
      el.saveNote.textContent = done.length + 'টি ফাইল ডাউনলোড শুরু হয়েছে। কোনোটা না নামলে নিচের তালিকা থেকে আলাদাভাবে "ডাউনলোড" চাপুন।';
      el.saveFolderBtn.disabled = false;
    });

    el.convertAnotherBtn.addEventListener('click', () => {
      files = []; showWarnings([]);
      el.resultCard.hidden = true; el.logCard.hidden = true; el.saveNote.hidden = true;
      renderFiles();
      el.dropzone.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });

    renderTypeRow(); renderSubRow(); applySettingsText(); renderFiles();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
