/**
 * config.js — সাইটের পরিবর্তনযোগ্য সেটিংস (কোড না ছুঁয়েই বদলানো যায়)
 */
window.CONVERTER_CONFIG = {
  /**
   * .doc → .docx রূপান্তরের লিংক (কনভার্শন বাটনের নিচের সতর্কতার উপরে দেখায়)।
   *
   * নিজস্ব সার্ভারে টুল বানালে শুধু url (আর দরকার হলে label) বদলে দিন, যেমন:
   *   url: 'https://at-tahreek.com/doc-to-docx/', label: 'আমাদের ফ্রি .doc → .docx টুল', newTab: false
   * লিংক পুরোপুরি লুকাতে:  url: ''
   */
  docToDocx: {
    url: 'https://www.freeconvert.com/doc-to-docx',
    label: '(.doc) ফাইলকে (.docx) এ রূপান্তর করতে ক্লিক করুন',
    newTab: true,

    /**
     * (ঐচ্ছিক হুক) সরাসরি API/সার্ভার ইন্টিগ্রেশনের জন্য। এখানে একটা async ফাংশন বসালে
     * ইউজার .doc ফাইল দিলে অ্যাপ সেটা দিয়ে নিজে থেকেই .docx বানিয়ে নেবে:
     *   api: async (file) => { ...আপলোড করে...; return docxBlobOrFile; }
     * null থাকলে .doc ফাইল ফিরিয়ে দিয়ে ইউজারকে উপরের লিংকে পাঠানো হয়।
     */
    api: null
  }
};
