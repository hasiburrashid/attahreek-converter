/**
 * engine-core.js
 * --------------
 * ENGINE_DATA (js/engine-data.js — আসল /modules/* থেকে অটো-রেকর্ড করা চেইন) চালানোর ইঞ্জিন।
 *
 * কেন আসল মডিউল সরাসরি রান করা হয় না: common.js ডোমেইন-লকড, defualt.js DOM-নির্ভর
 * (textarea পড়ে/লেখে), আর আসল ফাংশনগুলো শুধু প্লেইন স্ট্রিং নেয় — ফলে কোন আউটপুট
 * ক্যারেক্টার Word-এর কোন <w:r> রান থেকে এসেছে (bold/italic/size ধরে রাখতে যা দরকার)
 * সেটা জানা যায় না। তাই এখানে একই চেইন একই ক্রমে চালানো হয়, কিন্তু প্রতিটা ক্যারেক্টারের
 * সাথে তার "origin range" বহন করা হয়।
 *
 * টেক্সটের ফলাফল আসল মডিউলের সাথে হুবহু মেলে — tools/regress.js আসল মডিউল চালিয়ে
 * হাজার হাজার ইনপুটে এটা যাচাই করে (origin শুধু অতিরিক্ত তথ্য, টেক্সট বদলায় না)।
 *
 * API:
 *   Engines.get(key)  -> { getMatches(text, opts), convertText(text) }
 *   key: 'u2b-2003' | 'u2b-classic' | 'b2u-2003' | 'b2u-classic'
 *        | 'b2b-2003-classic' | 'b2b-classic-2003'
 *   getMatches(text, {paragraphStart}) -> [{start, length, replacement}]
 *     paragraphStart:true হলে টেক্সটের আগে একটা ভার্চুয়াল "\n" বসানো হয় — আসল সাইটে পুরো
 *     ডকুমেন্ট একটাই টেক্সটবক্সে থাকে, প্যারাগ্রাফ "\n" দিয়ে আলাদা; আর finishingTouch এর
 *     "\n‡"->"\n†" জাতীয় রুল প্যারাগ্রাফের শুরুতে কাজ করে।
 */
(function (root) {
  'use strict';

  // ---- common.js এর হেল্পার (আসল সংজ্ঞা থেকে হুবহু) ----
  const BANJON = new Set(
    'কখগঘঙচছজঝঞটঠডঢণত' +
    'থদধনপফবভমশষসহযরল' +
    'য়ংঃঁৎ');
  const PRE = new Set(['ি', 'ৈ', 'ে']);
  const POST = new Set(['া', 'ো', 'ৌ', 'ৗ', 'ু', 'ূ', 'ী', 'ৃ']);
  const NUKTA = new Set(['ং', 'ঃ', 'ঁ']);
  const isBanjon = c => BANJON.has(c);
  const isPre = c => PRE.has(c);
  const isPost = c => POST.has(c);
  const isKar = c => PRE.has(c) || POST.has(c);
  const isNukta = c => NUKTA.has(c);
  const isHalant = c => c === '্';
  const isSpace = c => c === ' ' || c === '\t' || c === '\n' || c === '\r';

  // ---- positioned state: { s, os[], oe[] } ----
  function makeState(text, prefix) {
    const os = [], oe = [];
    let s = text;
    if (prefix) {
      s = prefix + text;
      for (let i = 0; i < prefix.length; i++) { os.push(0); oe.push(0); } // শূন্য-দৈর্ঘ্যের origin
    }
    for (let i = 0; i < text.length; i++) { os.push(i); oe.push(i + 1); }
    return { s, os, oe };
  }

  function expand(repl, m, input) {
    if (repl.indexOf('$') < 0) return repl;
    let out = '';
    for (let i = 0; i < repl.length; i++) {
      const c = repl[i];
      if (c !== '$' || i === repl.length - 1) { out += c; continue; }
      const d = repl[i + 1];
      if (d === '$') { out += '$'; i++; }
      else if (d === '&') { out += m[0]; i++; }
      else if (d === '`') { out += input.slice(0, m.index); i++; }
      else if (d === "'") { out += input.slice(m.index + m[0].length); i++; }
      else if (d >= '0' && d <= '9') {
        let n = +d, used = 1;
        const d2 = repl[i + 2];
        if (d2 >= '0' && d2 <= '9' && +(d + d2) < m.length && +(d + d2) > 0) { n = +(d + d2); used = 2; }
        if (n >= 1 && n < m.length) { out += m[n] === undefined ? '' : m[n]; i += used; }
        else out += c;
      } else out += c;
    }
    return out;
  }

  /**
   * মিলে যাওয়া অংশ (mt) ও তার রিপ্লেসমেন্ট (r) এর common prefix/suffix এর ক্যারেক্টারগুলো নিজ নিজ
   * origin ধরে রাখে; মাঝের বদলে যাওয়া অংশ পায় মিলে যাওয়া অংশের merged origin range।
   * (এতে একটা রেজেক্সের কনটেক্সট-ক্যারেক্টার, যেমন "$1†" এর $1, আলাদা রানেই থাকে)
   */
  function pushReplaced(out, st, a, mt, r) {
    const b = a + mt.length;
    const lim = Math.min(mt.length, r.length);
    let p = 0;
    while (p < lim && mt.charCodeAt(p) === r.charCodeAt(p)) p++;
    let q = 0;
    while (q < lim - p && mt.charCodeAt(mt.length - 1 - q) === r.charCodeAt(r.length - 1 - q)) q++;
    for (let i = 0; i < p; i++) { out.s += mt[i]; out.os.push(st.os[a + i]); out.oe.push(st.oe[a + i]); }
    const midR = r.slice(p, r.length - q);
    if (midR.length) {
      let lo, hi;
      if (b - q > a + p) {
        lo = Infinity; hi = -Infinity;
        for (let i = a + p; i < b - q; i++) { if (st.os[i] < lo) lo = st.os[i]; if (st.oe[i] > hi) hi = st.oe[i]; }
      } else { // কিছু মোছা হয়নি, শুধু ঢোকানো — পাশের ক্যারেক্টারের পজিশনে বসাও
        const k = a + p;
        const v = k < st.s.length ? st.os[k] : (st.s.length ? st.oe[st.s.length - 1] : 0);
        lo = v; hi = v;
      }
      for (let i = 0; i < midR.length; i++) { out.s += midR[i]; out.os.push(lo); out.oe.push(hi); }
    }
    for (let i = 0; i < q; i++) {
      const si = b - q + i;
      out.s += r[r.length - q + i]; out.os.push(st.os[si]); out.oe.push(st.oe[si]);
    }
  }

  function copyRange(out, st, from, to) {
    for (let i = from; i < to; i++) { out.s += st.s[i]; out.os.push(st.os[i]); out.oe.push(st.oe[i]); }
  }

  /** global regex replace — আসল String.replace এর মতোই, সাথে origin-tracking */
  function applyRegex(st, re, replOrFn) {
    re.lastIndex = 0;
    let m = re.exec(st.s);
    if (!m) return st;
    const input = st.s;
    const out = { s: '', os: [], oe: [] };
    let last = 0;
    while (m) {
      const a = m.index;
      copyRange(out, st, last, a);
      const r = typeof replOrFn === 'function' ? replOrFn(m) : expand(replOrFn, m, input);
      pushReplaced(out, st, a, m[0], r);
      last = a + m[0].length;
      if (m[0].length === 0) re.lastIndex++;
      m = re.exec(input);
    }
    copyRange(out, st, last, input.length);
    return out;
  }

  /** স্ট্রিং-প্যাটার্ন replace — শুধু প্রথম occurrence (String.replace(string, string) এর মতো) */
  function applyStringFirst(st, pat, repl) {
    const i = st.s.indexOf(pat);
    if (i < 0) return st;
    const r = expand(repl, Object.assign([pat], { index: i }), st.s);
    const out = { s: '', os: [], oe: [] };
    copyRange(out, st, 0, i);
    pushReplaced(out, st, i, pat, r);
    copyRange(out, st, i + pat.length, st.s.length);
    return out;
  }

  // ---- procedural ধাপ: item অ্যারে ({c, os, oe}) এর উপর ----
  function toItems(st) {
    const A = new Array(st.s.length);
    for (let i = 0; i < A.length; i++) A[i] = { c: st.s[i], os: st.os[i], oe: st.oe[i] };
    return A;
  }
  function fromItems(A) {
    const st = { s: '', os: [], oe: [] };
    for (const it of A) { st.s += it.c; st.os.push(it.os); st.oe.push(it.oe); }
    return st;
  }
  // JS এর charAt / substring এর হুবহু আচরণ (রেঞ্জের বাইরে '' ; substring এ clamp ও swap)
  function accessors(getA) {
    const ch = i => { const A = getA(); return i >= 0 && i < A.length ? A[i].c : ''; };
    const at = i => { const A = getA(); return i >= 0 && i < A.length ? [A[i]] : []; };
    const sub = (a, b) => {
      const A = getA(); const n = A.length;
      a = a < 0 ? 0 : a > n ? n : a; b = b < 0 ? 0 : b > n ? n : b;
      return a > b ? A.slice(b, a) : A.slice(a, b);
    };
    return { ch, at, sub };
  }

  /** rconverter.js: ReArrangeUnicodeText() — প্রি-কার ও রেফ কে Bijoy টাইপিং-অর্ডারে সাজানো */
  function reArrangeUnicodeText(st) {
    let A = toItems(st);
    const { ch, at, sub } = accessors(() => A);
    let v4 = 0;
    for (let i = 0; i < A.length; i++) {
      if (i < A.length && isPre(ch(i))) {
        let j = 1;
        while (isBanjon(ch(i - j))) {
          if (i - j < 0) break;
          if (i - j <= v4) break;
          if (isHalant(ch(i - j - 1))) j += 2; else break;
        }
        A = sub(0, i - j).concat(at(i), sub(i - j, i), sub(i + 1, A.length));
        v4 = i + 1;
        continue;
      }
      if (i < A.length - 1 && isHalant(ch(i)) && ch(i - 1) === 'র' && !isHalant(ch(i - 2))) {
        let j = 1, k = 0;
        while (true) {
          if (isBanjon(ch(i + j)) && isHalant(ch(i + j + 1))) j += 2;
          else if (isBanjon(ch(i + j)) && isPre(ch(i + j + 1))) { k = 1; break; }
          else break;
        }
        A = sub(0, i - 1).concat(sub(i + j + 1, i + j + k + 1), sub(i + 1, i + j + 1),
          at(i - 1), at(i), sub(i + j + k + 1, A.length));
        i += (j + k);
        v4 = i + 1;
        continue;
      }
    }
    return fromItems(A);
  }

  /** converter.js: ReArrangeUnicodeConvertedText() — Bijoy→Unicode এর পর কার/রেফ ঠিক জায়গায় আনা */
  function reArrangeUnicodeConvertedText(st) {
    let A = toItems(st);
    const { ch, at, sub } = accessors(() => A);
    for (let i = 0; i < A.length; i++) {
      if (i > 0 && ch(i) === '্' && (isKar(ch(i - 1)) || isNukta(ch(i - 1))) && i < A.length - 1) {
        A = sub(0, i - 1).concat(at(i), at(i + 1), at(i - 1), sub(i + 2, A.length));
      }
      if (i > 0 && i < A.length - 1 && ch(i) === '্' && ch(i - 1) === 'র' &&
          ch(i - 2) !== '্' && isKar(ch(i + 1))) {
        A = sub(0, i - 1).concat(at(i + 1), at(i - 1), at(i), sub(i + 2, A.length));
      }
      if (i < A.length - 1 && ch(i) === 'র' && isHalant(ch(i + 1)) && !isHalant(ch(i - 1))) {
        let j = 1;
        while (true) {
          if (i - j < 0) break;
          if (isBanjon(ch(i - j)) && isHalant(ch(i - j - 1))) j += 2;
          else if (j === 1 && isKar(ch(i - j))) j++;
          else break;
        }
        A = sub(0, i - j).concat(at(i), at(i + 1), sub(i - j, i), sub(i + 2, A.length));
        i += 1;
        continue;
      }
      if (i < A.length - 1 && isPre(ch(i)) && isSpace(ch(i + 1)) === false) {
        let B = sub(0, i);
        let j = 1;
        while (isBanjon(ch(i + j))) {
          if (isHalant(ch(i + j + 1))) j += 2; else break;
        }
        B = B.concat(sub(i + 1, i + j + 1));
        let k = 0;
        if (ch(i) === 'ে' && ch(i + j + 1) === 'া') {
          const x = A[i], y = A[i + j + 1];
          B.push({ c: 'ো', os: Math.min(x.os, y.os), oe: Math.max(x.oe, y.oe) }); k = 1;
        } else if (ch(i) === 'ে' && ch(i + j + 1) === 'ৗ') {
          const x = A[i], y = A[i + j + 1];
          B.push({ c: 'ৌ', os: Math.min(x.os, y.os), oe: Math.max(x.oe, y.oe) }); k = 1;
        } else {
          B = B.concat(at(i));
        }
        B = B.concat(sub(i + j + k + 1, A.length));
        A = B;
        i += j;
      }
      if (i < A.length - 1 && ch(i) === 'ঁ' && isPost(ch(i + 1))) {
        A = sub(0, i).concat(at(i + 1), at(i), sub(i + 2, A.length));
      }
    }
    return fromItems(A);
  }

  const PROCS = {
    ReArrangeUnicodeText: reArrangeUnicodeText,
    ReArrangeUnicodeConvertedText: reArrangeUnicodeConvertedText
  };

  // ---- চেইন কম্পাইল ও চালানো ----
  function compile(ops) {
    return ops.map(op => {
      if (Array.isArray(op)) return { k: 're', re: new RegExp(op[0], 'g'), r: op[1] };
      if (op.t === 'str') return { k: 'str', p: op.p, r: op.r };
      if (op.t === 'start') return { k: 'start', p: op.p, r: op.r };
      if (op.t === 'proc') {
        if (!PROCS[op.n]) throw new Error('অজানা procedural ধাপ: ' + op.n);
        return { k: 'proc', f: PROCS[op.n] };
      }
      if (op.t === 'tbl') {
        const re = new RegExp(op.src, op.flags);
        const table = op.table;
        const fn = m => (op.prevGroup && m[1]) ? m[1] + op.prevSuffix : table[m[0]];
        return { k: 'tbl', re, fn };
      }
      throw new Error('অজানা ধাপ');
    });
  }

  function buildSpans(st) {
    const spans = [];
    const n = st.s.length;
    let i = 0;
    while (i < n) {
      let curStart = st.os[i], curEnd = st.oe[i], rep = st.s[i], j = i + 1;
      // শুধু strict overlap এ merge — adjacent/touching মানে স্বাভাবিক ধারাবাহিক টেক্সট
      while (j < n && st.os[j] < curEnd) {
        if (st.oe[j] > curEnd) curEnd = st.oe[j];
        if (st.os[j] < curStart) curStart = st.os[j];
        rep += st.s[j]; j++;
      }
      spans.push({ start: curStart, length: curEnd - curStart, replacement: rep });
      i = j;
    }
    // দ্বিতীয় পাস: একটা span আগেরটার রেঞ্জের ভেতর ঢুকে গেলে (রি-অর্ডারের কারণে) জোড়া দিয়ে
    // নিশ্চিত করা যে span গুলো ক্রমানুসারে ও পরস্পর-বিচ্ছিন্ন
    const merged = [];
    const overlaps = (p, q) => q.start < p.start + p.length || q.start < p.start;
    for (const sp of spans) {
      let cur = { start: sp.start, length: sp.length, replacement: sp.replacement };
      // আগের span এর সাথে ওভারল্যাপ করলে জোড়া দাও; জোড়া লাগার পর আরও পেছনেরটার সাথেও মিলতে পারে
      while (merged.length && overlaps(merged[merged.length - 1], cur)) {
        const prev = merged.pop();
        const end = Math.max(prev.start + prev.length, cur.start + cur.length);
        const start = Math.min(prev.start, cur.start);
        cur = { start, length: end - start, replacement: prev.replacement + cur.replacement };
      }
      merged.push(cur);
    }
    return merged;
  }

  function createEngine(ops) {
    const chain = compile(ops);

    function run(text, opts) {
      const prefix = opts && opts.paragraphStart ? '\n' : '';
      let st = makeState(text, prefix);
      for (const op of chain) {
        if (op.k === 're') st = applyRegex(st, op.re, op.r);
        else if (op.k === 'tbl') st = applyRegex(st, op.re, op.fn);
        else if (op.k === 'str') st = applyStringFirst(st, op.p, op.r);
        else if (op.k === 'start') { if (st.s.slice(0, op.p.length) === op.p) st = applyStringFirst(st, op.p, op.r); }
        else st = op.f(st);
      }
      if (prefix) {
        // ভার্চুয়াল "\n" ক্যারেক্টারটা খুঁজে সরিয়ে ফেলা (সাধারণত সবার শুরুতে থাকে; ইনপুট কার/হসন্ত দিয়ে
        // শুরু হলে রি-অ্যারেঞ্জ ধাপ সেটাকে একটু পেছনে ঠেলে দিতে পারে — তবুও সরাতে হবে)
        for (let i = 0; i < st.s.length; i++) {
          if (st.s[i] === '\n' && st.os[i] === 0 && st.oe[i] === 0) {
            st = { s: st.s.slice(0, i) + st.s.slice(i + 1), os: st.os.slice(0, i).concat(st.os.slice(i + 1)), oe: st.oe.slice(0, i).concat(st.oe.slice(i + 1)) };
            break;
          }
        }
      }
      return st;
    }

    return {
      getMatches(text, opts) { return text ? buildSpans(run(text, opts)) : []; },
      convertText(text, opts) { return text ? run(text, opts).s : text; }
    };
  }

  const cache = {};
  const Engines = {
    get(key) {
      if (!cache[key]) {
        const data = root.ENGINE_DATA && root.ENGINE_DATA[key];
        if (!data) throw new Error('ইঞ্জিন পাওয়া যায়নি: ' + key);
        cache[key] = createEngine(data);
      }
      return cache[key];
    },
    create: createEngine
  };

  root.Engines = Engines;
  if (typeof module !== 'undefined' && module.exports) module.exports = Engines;
})(typeof window !== 'undefined' ? window : globalThis);
