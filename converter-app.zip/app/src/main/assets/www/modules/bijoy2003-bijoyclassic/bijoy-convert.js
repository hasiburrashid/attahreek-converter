// modules/bijoy2003-bijoyclassic/bijoy-convert.js
//
// বিজয় (২০০৩) <-> বিজয় (ক্লাসিক) — সরাসরি ANSI থেকে ANSI কনভার্টার। ইউনিকোড নেই।
//
// মূল নিয়ম: কার/ফলার ক্রম কখনো বদলায় না ("‡K" দুই দিকেই "‡K")।
// শুধু যে কোডগুলো দুই সংস্করণে ভিন্ন গ্লিফ বোঝায়, সেগুলোই বদলায়।
//
// এই তালিকা হাতে লেখা নয়: unicode-bijoy2003 ও unicode-bijoyclassic — এই দুই
// মডিউলের আসল পাইপলাইনে ৩২ হাজারের বেশি বাংলা শব্দ/যুক্তাক্ষর চালিয়ে দুই আউটপুট
// মিলিয়ে বের করা হয়েছে।
//
// একটাই রেজেক্স, একটাই পাস: বদলানোর আউটপুট আর কখনো নতুন করে ম্যাচ হয় না
// (নইলে 'ø'->'mœ' আর '−'->'ø' এক সাথে চালালে একটা আরেকটাকে নষ্ট করত)।

(function () {
  "use strict";

  // ---------- ২০০৩ -> ক্লাসিক ----------
  var TO_CLASSIC = {
    "m&c\u2212": "\u00AF\u00FA\u00F8",            // স্প্ল : m&c−  -> ¯úø
    "\u00AF\u2212": "\u00AF\u00F8",                // স্ল : ¯− -> ¯ø   (নতুন)
    "N\u2212": "N\u00AC",                           // ঘ্ল   : N−    -> N¬
    "W\u00A5": "W&g",                               // ড্ম   : W¥    -> W&g
    "\u201C": "\u00E6",                             // ু (র-ফলার পর) : “ -> æ   (ত্রু, শ্রু, রু ...)
    "\u00CD": "Z\u00A5",                            // ত্ম   : Í     -> Z¥
    "\u2014": "\u00CD",                             // ত্ (ন্ত, স্ত) : — -> Í
    "\u00E6": "g\u0153",                            // ম্ন   : æ     -> gœ
    "\u00CA": "\u00D0",                             // ণ্ড   : Ê     -> Ð
    "\u00F8": "m\u0153"                             // স্ন   : ø     -> mœ
  };
  // ল-ফলা: কিছু বর্ণের পর '−' (U+2212) ক্লাসিকে 'ø' হয়: গ্ল প্ল ব্ল ম্ল ল্ল শ্ল ম্প্ল
  // অন্য বর্ণের পরে (যেমন স্ল = ¯−) '−' একই থাকে।
  var RE_TO_CLASSIC =
    /m&c\u2212|\u00AF\u2212|([cj\u00A4eMk\u00FA])\u2212|N\u2212|W\u00A5|[\u201C\u00CD\u2014\u00E6\u00CA\u00F8]/g;

  // ---------- ক্লাসিক -> ২০০৩ ----------
  var TO_2003 = {
    "\u00AF\u00FA\u00F8": "m&c\u2212", // স্প্ল : ¯úø -> m&c−
    "\u2022g\u0153": "\u2022g\u0153",  // ঙ্ম্ন : •gœ -> একই (নিচের 'gœ' নিয়ম যেন না ধরে)
    "N\u00AC": "N\u2212",              // ঘ্ল   : N¬ -> N−
    "W&g": "W\u00A5",                  // ড্ম   : W&g -> W¥
    "Z\u00A5": "\u00CD",               // ত্ম   : Z¥ -> Í
    "g\u0153": "\u00E6",               // ম্ন   : gœ -> æ
    "m\u0153": "\u00F8",               // স্ন   : mœ -> ø
    "\u00CD": "\u2014",                // ত্ (ন্ত, স্ত) : Í -> —
    "\u00D0": "\u00CA",                // ণ্ড   : Ð -> Ê
    "\u00E6": "\u201C",                // ু (র-ফলার পর) : æ -> “
    "\u00F8": "\u2212",                 // ল-ফলা : ø -> −
    "\u00FF": "\u00B6"                 // ক্ষ : ÿ -> ¶
  };
  var RE_TO_2003 =
     /\u00AF\u00FA\u00F8|\u2022g\u0153|N\u00AC|W&g|Z\u00A5|g\u0153|m\u0153|[\u00CD\u00D0\u00E6\u00F8\u00FF]/g;
  // বাইরে থেকেও ডাকা যাবে (টেস্ট বা অন্য মডিউলের জন্য)
  window.bijoy2003ToClassic = function (text) {
    return text.replace(RE_TO_CLASSIC, function (m, prev) {
      return prev ? prev + "\u00F8" : TO_CLASSIC[m];
    });
  };
  window.bijoyClassicTo2003 = function (text) {
    return text.replace(RE_TO_2003, function (m) { return TO_2003[m]; });
  };

  // ---------- UI ----------
  var ID_2003 = "b2003Text";
  var ID_CLASSIC = "classicText";

  function $(id) { return document.getElementById(id); }

  function toast(id) {
    var el = $(id);
    if (!el) return;
    el.classList.add("toastShow");
    setTimeout(function () { el.classList.remove("toastShow"); }, 3000);
  }

  // লাইভ টাইপিং
  $(ID_2003).oninput = function () {
    $(ID_CLASSIC).value = window.bijoy2003ToClassic($(ID_2003).value);
  };
  $(ID_CLASSIC).oninput = function () {
    $(ID_2003).value = window.bijoyClassicTo2003($(ID_CLASSIC).value);
  };

  // প্যানেলের inline onclick এই গ্লোবালগুলোই ডাকে
  window.clearText = function () {
    if ($(ID_2003).value === "" && $(ID_CLASSIC).value === "") {
      toast("funcFailed");
      return;
    }
    $(ID_2003).value = "";
    $(ID_CLASSIC).value = "";
    toast("clearSuccess");
  };

  window.doCopy = function (id) {
    var box = $(id);
    if (!box || box.value === "") {
      toast("funcFailed");
      return;
    }
    box.select();
    box.setSelectionRange(0, 99999);
    document.execCommand("copy");
    toast("copySuccess");
  };

  function pasteInto(srcId, dstId, convert) {
    navigator.clipboard.readText().then(function (text) {
      if (text === "") { toast("pasteEmpty"); return; }
      $(srcId).value = text;
      $(dstId).value = convert(text);
      toast("pasteSuccess");
    }).catch(function () { toast("pasteFailed"); });
  }

  $("paste2003").addEventListener("click", function () {
    pasteInto(ID_2003, ID_CLASSIC, window.bijoy2003ToClassic);
  });
  $("pasteClassic").addEventListener("click", function () {
    pasteInto(ID_CLASSIC, ID_2003, window.bijoyClassicTo2003);
  });
})();
